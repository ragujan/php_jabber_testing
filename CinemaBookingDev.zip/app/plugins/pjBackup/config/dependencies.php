<?php
return array(
	'jquery' => '>=1.8.2',
	'jquery_ui' => '>=1.9.1',
);
?>