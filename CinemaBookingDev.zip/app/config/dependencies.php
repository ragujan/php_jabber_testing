<?php
return array(
	'jquery' => '>=1.11.3',
	'jquery_migrate' => '>=1.3.0',
	'jquery_ui' => '>=1.10.4',
	'tipsy' => '>=1.0.0',
	'validate' => '^1.14.0',
	'tinymce' => '>=4.1.1',
	'timepicker' => '>=1.3.0',
	'multiselect' => '>=1.13.0',
	'chosen' => '>=0.9.8',
	'barcode' => '>=6.0.0',
	'tcpdf' => '>=6.4.4',
	'pj_bootstrap' => '>=3.3.2',
	'font_awesome' => '>=4.4.0',
	'pj_jquery' => '>=1.11.2',
	'pj_jquery_ui' => '>=1.9.2',
	'pj_validate' => '>=1.10.0',
	'storage_polyfill' => '>=1.0.0',
);
?>